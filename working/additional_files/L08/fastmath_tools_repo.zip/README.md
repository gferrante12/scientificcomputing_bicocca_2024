# fastmath_tools

Example educational repository for:
- Building and packaging a Python module
- Unit and regression testing with GitHub Actions
- Profiling and speeding up code with Numba

## Installation
```
pip install .
```

## Testing
```
pytest -v
```

## Publishing to Test PyPI
```
python setup.py sdist bdist_wheel
twine upload --repository testpypi dist/*
```
