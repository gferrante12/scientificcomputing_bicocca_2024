import numpy as np
from numba import njit

def slow_sum(arr):
    total = 0.0
    for a in arr:
        total += a
    return total

@njit
def fast_sum(arr):
    total = 0.0
    for a in arr:
        total += a
    return total

def profile_demo(size=10_000_000):
    import time
    arr = np.random.rand(size)
    t0 = time.time()
    s1 = slow_sum(arr)
    t1 = time.time()
    s2 = fast_sum(arr)
    t2 = time.time()
    return {
        "slow_time": t1 - t0,
        "fast_time": t2 - t1,
        "ratio": (t1 - t0) / (t2 - t1),
        "diff": abs(s1 - s2)
    }
